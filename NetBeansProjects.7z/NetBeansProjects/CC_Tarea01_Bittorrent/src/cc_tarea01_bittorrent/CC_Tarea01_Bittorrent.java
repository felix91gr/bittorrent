/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cc_tarea01_bittorrent;

/**
 *
 * @author ffischer
 */
public class CC_Tarea01_Bittorrent {

    private static void printLn(String arg){
        System.out.println(arg);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        printLn("wololo, wololo");
        // TODO code application logic here
    }
    
}
